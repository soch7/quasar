<template>
<q-parallax
        src="../images/interests.png">
<div class="c1">
<h4> Interests :</h4>
   <ul style="font-size:20px">
              <li>Oil pastels Drawing </li>
              <li>Travelling and exploring new places</li>
              <li>Learning new languages</li>
              <li>Watching movies</li>
                           
            </ul>
            </div>
    </q-parallax>
</template>
            <script>
            import { defineComponent } from 'vue'

export default defineComponent({
  name: 'PersonalDetails',
})</script>
<style>
{
background-color: lightblue
}
</style>